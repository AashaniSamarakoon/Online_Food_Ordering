package com.delivery.driverauthservice.model;

public enum DocumentType {
    PROFILE_PHOTO,
    DRIVING_LICENSE,
    VEHICLE_INSURANCE,
    REVENUE_LICENSE,
    VEHICLE_REGISTRATION
}