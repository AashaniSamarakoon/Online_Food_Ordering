package com.delivery.driverauthservice.messaging;

public class DriverRegistrationConsumer {
}
