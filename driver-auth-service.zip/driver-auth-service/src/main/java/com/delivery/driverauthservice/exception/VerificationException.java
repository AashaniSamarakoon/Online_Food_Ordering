package com.delivery.driverauthservice.exception;

public class VerificationException extends RuntimeException {
    public VerificationException(String message) {
        super(message);
    }
}
