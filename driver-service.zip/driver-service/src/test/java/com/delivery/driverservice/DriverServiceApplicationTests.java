package com.delivery.driverservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")

class DriverServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
